"""
Iris dataset explorer
"""
import streamlit as st

st.title("Iris dataset explorer")
st.markdown(
    """
    ### This app allows you to explore the Iris dataset
    """
)
